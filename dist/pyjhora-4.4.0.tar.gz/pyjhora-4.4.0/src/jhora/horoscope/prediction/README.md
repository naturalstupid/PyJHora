### The files in this folder are for experimental purpose only based on rules specified in various books
Please try with your own discretion
